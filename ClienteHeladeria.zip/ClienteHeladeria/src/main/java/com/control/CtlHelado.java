package com.control;

import java.io.Serializable;
import com.objeto.ObjHelado;
import com.servicio.SrvHelado;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

@Named
@ViewScoped
public class CtlHelado implements Serializable {
    
    private List<ObjHelado> listaHelados;    
    SrvHelado srvhelado = new SrvHelado();
    
    @PostConstruct
    public void init() {
        listaHelados = srvhelado.mtdObtenerHelado();
    }

    public List<ObjHelado> getListaHelados() {
        return listaHelados;
    }

    public void setListaHelados(List<ObjHelado> listaHelados) {
        this.listaHelados = listaHelados;
    }

    public SrvHelado getSrvhelado() {
        return srvhelado;
    }

    public void setSrvhelado(SrvHelado srvhelado) {
        this.srvhelado = srvhelado;
    }
}