#!/bin/sh
mvn clean package && docker build -t com/ServidorAlmacen .
docker rm -f ServidorAlmacen || true && docker run -d -p 8080:8080 -p 4848:4848 --name ServidorAlmacen com/ServidorAlmacen 
