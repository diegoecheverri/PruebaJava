package com.modelo;

import com.utilidad.ClsFacade;
import com.objeto.ObjSabor;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author alejo
 */
@Stateless
public class MdlSabor extends ClsFacade<ObjSabor> {

    @PersistenceContext(unitName = "Persistencia_ServidorHeladeria")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MdlSabor() {
        super(ObjSabor.class);
    }
}
