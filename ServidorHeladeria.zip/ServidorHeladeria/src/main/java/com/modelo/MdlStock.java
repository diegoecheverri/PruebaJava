package com.modelo;

import com.utilidad.ClsFacade;
import com.objeto.ObjStock;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author alejo
 */
@Stateless
public class MdlStock extends ClsFacade<ObjStock> {

    @PersistenceContext(unitName = "Persistencia_ServidorHeladeria")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MdlStock() {
        super(ObjStock.class);
    }
}
