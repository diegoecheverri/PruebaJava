package com.objeto;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author alejo
 */
@Entity
@Table(name = "APP.HELADO_SABOR")
@XmlRootElement
public class ObjHeladoSabor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_HELADO_SABOR")
    private Integer idHeladoSabor;
    @JoinColumn(name = "ID_HELADO", referencedColumnName = "ID_HELADO")
    @ManyToOne
    private ObjHelado idHelado;
    @JoinColumn(name = "ID_SABOR", referencedColumnName = "ID_SABOR")
    @ManyToOne
    private ObjSabor idSabor;
    @OneToMany(mappedBy = "idHeladoSabor")
    private List<ObjStock> objStockList;

    public ObjHeladoSabor() {
    }

    public ObjHeladoSabor(Integer idHeladoSabor) {
        this.idHeladoSabor = idHeladoSabor;
    }

    public Integer getIdHeladoSabor() {
        return idHeladoSabor;
    }

    public void setIdHeladoSabor(Integer idHeladoSabor) {
        this.idHeladoSabor = idHeladoSabor;
    }

    public ObjHelado getIdHelado() {
        return idHelado;
    }

    public void setIdHelado(ObjHelado idHelado) {
        this.idHelado = idHelado;
    }

    public ObjSabor getIdSabor() {
        return idSabor;
    }

    public void setIdSabor(ObjSabor idSabor) {
        this.idSabor = idSabor;
    }

    @XmlTransient
    public List<ObjStock> getObjStockList() {
        return objStockList;
    }

    public void setObjStockList(List<ObjStock> objStockList) {
        this.objStockList = objStockList;
    }
}
