package com.objeto;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author alejo
 */
@Entity
@Table(name = "APP.STOCK")
@XmlRootElement
public class ObjStock implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID_STOCK")
    private Integer idStock;
    @Column(name = "CANTIDAD")
    private Integer cantidad;
    @Column(name = "MAXIMO_INVENTARIO")
    private Integer maximoInventario;
    @Column(name = "MINIMO_INVENTARIO")
    private Integer minimoInventario;
    @Column(name = "PRECIO")
    private Double precio;
    @JoinColumn(name = "ID_HELADO_SABOR", referencedColumnName = "ID_HELADO_SABOR")
    @ManyToOne
    private ObjHeladoSabor idHeladoSabor;

    public ObjStock() {
    }

    public ObjStock(Integer idStock) {
        this.idStock = idStock;
    }

    public Integer getIdStock() {
        return idStock;
    }

    public void setIdStock(Integer idStock) {
        this.idStock = idStock;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getMaximoInventario() {
        return maximoInventario;
    }

    public void setMaximoInventario(Integer maximoInventario) {
        this.maximoInventario = maximoInventario;
    }

    public Integer getMinimoInventario() {
        return minimoInventario;
    }

    public void setMinimoInventario(Integer minimoInventario) {
        this.minimoInventario = minimoInventario;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public ObjHeladoSabor getIdHeladoSabor() {
        return idHeladoSabor;
    }

    public void setIdHeladoSabor(ObjHeladoSabor idHeladoSabor) {
        this.idHeladoSabor = idHeladoSabor;
    }
}
