package com.servicio;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import com.modelo.MdlHelado;
import com.objeto.ObjHelado;
import java.util.List;
import javax.ejb.Stateless;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Stateless
@Path("srvhelado")
public class SrvHelado {

    @EJB
    MdlHelado mdlhelado;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    public void mtdInsertarHelado(ObjHelado objhelado) {
        mdlhelado.create(objhelado);
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public List<ObjHelado> mtdObtenerHelado() {
        return mdlhelado.findAll();
    }

    @DELETE
    @Path("{id}")
    public void mtdEliminarHelado(@PathParam("id") Integer id) {
        mdlhelado.remove(mdlhelado.find(id));
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_JSON})
    public void mtdEditarHelado(@PathParam("id") Integer id, ObjHelado objhelado) {
        mdlhelado.edit(objhelado);
    }
}
