package com.servicio;

import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import com.modelo.MdlHeladoSabor;
import com.objeto.ObjHeladoSabor;
import java.util.List;
import javax.ejb.Stateless;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Stateless
@Path("srvheladosabor")
public class SrvHeladoSabor {

    @EJB
    MdlHeladoSabor mdlheladosabor;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    public void mtdInsertarHeladoSabor(ObjHeladoSabor objheladosabor) {
        mdlheladosabor.create(objheladosabor);
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public List<ObjHeladoSabor> mtdObtenerHeladoSabor() {
        return mdlheladosabor.findAll();
    }

    @DELETE
    @Path("{id}")
    public void mtdEliminarHeladoSabor(@PathParam("id") Integer id) {
        mdlheladosabor.remove(mdlheladosabor.find(id));
    }
    
    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_JSON})
    public void mtdEditarHeladoSabor(@PathParam("id") Integer id, ObjHeladoSabor objheladosabor) {
        mdlheladosabor.edit(objheladosabor);
    }
}
