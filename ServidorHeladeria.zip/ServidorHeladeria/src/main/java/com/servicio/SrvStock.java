package com.servicio;

import com.modelo.MdlStock;
import com.objeto.ObjStock;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

@Stateless
@Path("srvstock")
public class SrvStock {

    @EJB
    MdlStock mdlstock;

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    public void mtdInsertarStock(ObjStock objstock) {
        mdlstock.create(objstock);
    }

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public List<ObjStock> mtdObtenerStock() {
        return mdlstock.findAll();
    }

    @DELETE
    @Path("{id}")
    public void mtdEliminarStock(@PathParam("id") Integer id) {
        mdlstock.remove(mdlstock.find(id));
    }
    
    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_JSON})
    public void mtdEditarStock(@PathParam("id") Integer id, ObjStock objstock) {
        mdlstock.edit(objstock);
    }
}
