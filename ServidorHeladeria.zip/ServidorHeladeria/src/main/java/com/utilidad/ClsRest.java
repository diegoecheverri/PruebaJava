package com.utilidad;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("recurso")
public class ClsRest extends Application {
}
